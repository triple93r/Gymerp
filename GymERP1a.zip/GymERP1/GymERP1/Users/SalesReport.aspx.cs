﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace GymERP1.Users
{
    public partial class SalesReport : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        GymERP1Entities1 db = new GymERP1Entities1();
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnFindByDate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select * from tblPurchaseBill where PurchaseDate between '" + txtFrom.Text + "' and '" + txtFrom.Text + "'", cons);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select * from tblPurchaseBill where PurchaseDate between '" + txtFrom.Text + "' and '" + txtTo.Text + "'", cons);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}