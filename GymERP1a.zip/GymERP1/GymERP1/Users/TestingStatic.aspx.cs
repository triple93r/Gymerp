﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GymERP1.Users
{
    public partial class TestingStatic : System.Web.UI.Page
    {
        static int s=0, d=0;
        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Text = "On page load" + s.ToString();
            if(!IsPostBack)
            {
                Label4.Text = "this is ispostack "+s.ToString();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            s += 1;
            Label1.Text = s.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Label2.Text = s.ToString();
        }
    }
}