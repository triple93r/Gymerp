﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using GymERP1.Users;

namespace GymERP1.Users
{
    public partial class AddProduct : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        //SqlCommand cmd;
        GymERP1Entities1 db = new GymERP1Entities1();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddNewBrand_Click(object sender, EventArgs e)
        {
            txtBrand.Enabled = true;
            btnSaveBrand.Enabled = true;

        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            using (var dbcon = new GymERP1Entities1())
            {
                var tbl = new tblProduct()
                {
                    ProductBrand = DpdnBrand.SelectedItem.Text,
                    ProductName = txtProdName.Text,
                    ProductFlavor = DpdnFlavor.SelectedItem.Text,
                    //ProductQty = txtQnty.Text,
                    ProdUnit = DpdnUnit.SelectedItem.Text,
                    ProductPrice = Convert.ToDecimal(txtPricePerUnit.Text),
                    ProdDescp = txtDescp.Text,
                    CreatedDate = DateTime.Now,
                    CreatedBy = "Admin"
                };
                dbcon.tblProducts.Add(tbl);
                dbcon.SaveChanges();
                lblConfirmAddProduct.Text = "Added Product!";
            }
        }

        protected void btnAddBrand_Click(object sender, EventArgs e)
        {
            if(txtBrand.Text!="")
            {
                using (var dbcon = new GymERP1Entities1())
                {
                    var tbl = new tblBrand()
                    {
                        BrandName = txtBrand.Text
                    };
                    dbcon.tblBrands.Add(tbl);
                    dbcon.SaveChanges();
                    lblConfirmBrandAdd.Text = "Added!";
                }
            }
        }
        protected void btnSaveFlavor_Click(object sender, EventArgs e)
        {
            if (txtProdFlavor.Text != "")
            {
                using (var dbcon = new GymERP1Entities1())
                {
                    var tbl = new tblFlavor()
                    {
                        Flavor = txtProdFlavor.Text
                    };
                    dbcon.tblFlavors.Add(tbl);
                    dbcon.SaveChanges();
                    lblConfirmFlavorAdd.Text = "Added!";
                }
            }
        }

        protected void btnSaveUnit_Click(object sender, EventArgs e)
        {
            if (txtAddNewUnit.Text != "")
            {
                using (var dbcon = new GymERP1Entities1())
                {
                    var tbl = new tblUnit()
                    {
                        UnitSize = txtAddNewUnit.Text
                    };
                    dbcon.tblUnits.Add(tbl);
                    dbcon.SaveChanges();
                    lblConfirmUnitAdd.Text = "Added!";
                }
            }
        }

        protected void btnAddNewFlavor_Click(object sender, EventArgs e)
        {
            txtProdFlavor.Enabled = true;
            btnSaveFlavor.Enabled = true;
        }

        protected void btnAddNewUnit_Click(object sender, EventArgs e)
        {
            txtAddNewUnit.Enabled = true;
            btnSaveUnit.Enabled = true;
        }
    }
}