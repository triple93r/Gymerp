﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GymERP1.Users
{
    public partial class AgentReport : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        GymERP1Entities1 db = new GymERP1Entities1();
        //SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnFindResult_Click(object sender, EventArgs e)
        {
            if(DpdnPurSale.SelectedIndex!=0)
            {
                if(DpdnPurSale.SelectedIndex==1)
                {

                }
                else if(DpdnPurSale.SelectedIndex==2)
                {

                }
            }
        }

        protected void btnFindByChoice_Click(object sender, EventArgs e)
        {

        }
    }
}