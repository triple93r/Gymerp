﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GymERP1.Users
{
    public partial class PurchaseItems : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        GymERP1Entities1 db = new GymERP1Entities1();
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                DpdnBrand.Items.Clear();
                DpdnFlavor.Items.Clear();
            }
        }

        protected void DpdnProdName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select ProdUnit from tblProducts where ProductName='"+DpdnProdName.SelectedItem.Text+"'", cons);
            cons.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            while(rd.Read())
            {
                txtUnit.Text = rd["ProdUnit"].ToString();
            }
            rd.Close();
            cons.Close();
            string prodname = DpdnProdName.SelectedItem.Text;
            var brandname = from s in db.tblProducts where s.ProductName.Equals(prodname) select new { s.ProductBrand };
            DpdnBrand.DataSource = brandname.ToList();
            DpdnBrand.DataTextField = "ProductBrand";
            DpdnBrand.DataValueField = "ProductBrand";
            DpdnBrand.DataBind();
            DpdnBrand.Items.Insert(0, "--Select--");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("spaddPurchase",cons);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@InvoiceNo",txtInvoice.Text);
            cmd.Parameters.AddWithValue("@Supplier",txtSupplier.Text);
            cmd.Parameters.AddWithValue("@BatchNo",txtBatch.Text);
            cmd.Parameters.AddWithValue("@Brand", DpdnBrand.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ProductName",DpdnProdName.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ProdFlavor", DpdnFlavor.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Unit",txtUnit.Text);
            cmd.Parameters.AddWithValue("@Quantity",Convert.ToInt32(txtQnty.Text));
            cmd.Parameters.AddWithValue("@Bulkrate", Convert.ToDecimal(txtBulkrate.Text));
            cmd.Parameters.AddWithValue("@GSTPercent",Convert.ToDecimal(txtGSTPercent.Text));
            cmd.Parameters.AddWithValue("@MRP4unit", Convert.ToDecimal(txtMRP4unit.Text)); 
            cmd.Parameters.AddWithValue("@TOTALprice",Convert.ToDecimal(txtTotPrice.Text));
            cmd.Parameters.AddWithValue("@RatePerUnit",Convert.ToDecimal(lblrate.Text));
            cmd.Parameters.AddWithValue("@PurchaseDate", Convert.ToDateTime(txtPurDate.Text));
            cons.Open();
            cmd.ExecuteNonQuery();
            cons.Close();
            lblConfirm.Text = "Data Added Successfully!";
        }

        protected void txtBulkrate_TextChanged(object sender, EventArgs e)
        {
            decimal BulkRate = 0, Qnty = 0, tot = 0;
            BulkRate = Convert.ToDecimal(txtBulkrate.Text);
            Qnty = Convert.ToDecimal(txtQnty.Text);
            tot = BulkRate / Qnty;
            lblrate.Text = tot.ToString();
        }

        protected void txtGSTPercent_TextChanged(object sender, EventArgs e)
        {
            decimal bulkrate = 0, gstpcnt = 0, totwgst=0;
            bulkrate = Convert.ToDecimal(txtBulkrate.Text);
            gstpcnt = Convert.ToDecimal(txtGSTPercent.Text);
            totwgst = bulkrate + (bulkrate * gstpcnt / 100);
            txtTotPrice.Text = totwgst.ToString();
        }

        protected void DpdnBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string prodname = DpdnProdName.SelectedItem.Text;
            //string brand = DpdnBrand.SelectedItem.Text;
            //var flavor = from s in db.tblProducts where (s.ProductName.Equals(prodname)) select s.ProductFlavor.Distinct();
            //DpdnFlavor.DataSource = flavor.ToList();
            //DpdnFlavor.DataTextField = "ProductFlavor";
            //DpdnFlavor.DataValueField = "ProductFlavor";
            //DpdnFlavor.DataBind();
            cmd = new SqlCommand("select distinct ProductFlavor from tblProducts where ProductName='"+DpdnProdName.SelectedItem.Text +"' and ProductBrand='"+DpdnBrand.SelectedItem.Text+"'", cons);
            SqlDataReader rd;
            cons.Open();
            DpdnFlavor.DataSource = cmd.ExecuteReader();
            DpdnFlavor.DataTextField = "ProductFlavor";
            DpdnFlavor.DataValueField = "ProductFlavor";
            DpdnFlavor.DataBind();
            cons.Close();
        }
    }
}