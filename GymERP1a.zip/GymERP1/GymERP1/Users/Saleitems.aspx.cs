﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GymERP1.Users
{
    public partial class Saleitems : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        GymERP1Entities1 db = new GymERP1Entities1();
        SqlCommand cmd;
        public decimal gstvalue { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("spAddSales", cons);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@OrderNo",txtOrderNo.Text);
            cmd.Parameters.AddWithValue("@InvoiceNo",txtInvoice.Text);
            cmd.Parameters.AddWithValue("@ProductName",DpdnProdName.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ProdFlavor",DpdnFlavor.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Batch",DpdnBatch.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ProdBrand",DpdnBrand.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ProdUnit",txtUNIT.Text);
            cmd.Parameters.AddWithValue("@Qnty",Convert.ToInt32(txtQnty.Text));
            cmd.Parameters.AddWithValue("@ProdRate",Convert.ToDecimal(txtRate.Text));
            cmd.Parameters.AddWithValue("@MRPrate", Convert.ToDecimal(txtMrp4unit.Text));
            cmd.Parameters.AddWithValue("@GrossAmt", Convert.ToDecimal(txtAmt.Text));
            cmd.Parameters.AddWithValue("@GST", Convert.ToDecimal(txtGSTAmt.Text));
            cmd.Parameters.AddWithValue("@TOTALamt", Convert.ToDecimal(txtTotalAmount.Text));
            cmd.Parameters.AddWithValue("@Profit", Convert.ToDecimal(lblProfit.Text));
            cmd.Parameters.AddWithValue("@discount", Convert.ToDecimal(lblDiscount.Text));
            cmd.Parameters.AddWithValue("@soldby", "Admin");
            cmd.Parameters.AddWithValue("@saledate", Convert.ToDateTime(txtDate.Text));
            cons.Open();
            cmd.ExecuteNonQuery();
            cons.Close();
            lblConfirm.Text = "Data Inserted Successfully!";
        }

        protected void DpdnProdName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select ProductBrand, ProductFlavor, ProdUnit from tblProducts where ProductName='" + DpdnProdName.SelectedItem.Text+"'", cons);
            SqlDataReader rd;
            cons.Open();
            DpdnBrand.DataSource = cmd.ExecuteReader();
            DpdnBrand.DataTextField = "ProductBrand";
            DpdnBrand.DataValueField = "ProductBrand";
            DpdnBrand.DataBind();
            cons.Close();
            cons.Open();
            DpdnFlavor.DataSource = cmd.ExecuteReader();
            DpdnFlavor.DataTextField = "ProductFlavor";
            DpdnFlavor.DataValueField = "ProductFlavor";
            DpdnFlavor.DataBind();
            cons.Close();
            cons.Open();
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                txtUNIT.Text = rd["ProdUnit"].ToString();
            }
            cmd.Dispose();
            cons.Close();
            cmd = new SqlCommand("select BatchNo from tblPurchaseBill where ProductName='"+DpdnProdName.SelectedItem.Text+"'", cons);
            cons.Open();
            DpdnBatch.DataSource = cmd.ExecuteReader();
            DpdnBatch.DataTextField = "BatchNo";
            DpdnBatch.DataValueField = "BatchNo";
            DpdnBatch.DataBind();
            //cmd.Dispose();
            cons.Close();
        }

        protected void txtRate_TextChanged(object sender, EventArgs e)
        {
            txtAmt.Text = (Convert.ToDecimal(txtQnty.Text) * Convert.ToDecimal(txtRate.Text)).ToString();
        }

        protected void txtGSTPercnt_TextChanged(object sender, EventArgs e)
        {
            decimal amt = 0.00M, prcnt = 0.00M;
            ViewState["amt"] = txtAmt.Text;
            amt = Convert.ToDecimal(ViewState["amt"]);
            prcnt = Convert.ToDecimal(txtGSTPercnt.Text);
            gstvalue = amt * (prcnt / 100);
            txtGSTAmt.Text = (amt*(prcnt/100)).ToString();
            txtTotalAmount.Text = (amt + (amt * (prcnt / 100))).ToString();
        }

        protected void DpdnBatch_SelectedIndexChanged(object sender, EventArgs e)
        {
            int purchaseQnty=0, SalesQnty=0, remainingqty=0;
            cmd = new SqlCommand("select sum(Quantity)[Purchase] from tblPurchaseBill where BatchNo='" + DpdnBatch.SelectedItem.Text + "' and ProductName='" + DpdnProdName.SelectedItem.Text + "' and Brand='" + DpdnBrand.SelectedItem.Text + "'", cons);
            cons.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                purchaseQnty = Convert.ToInt32(rd["Purchase"].ToString());
            }
            cons.Close();
            rd.Close();
            cmd.Dispose();
            SqlCommand cmdcount = new SqlCommand("select count(Qnty) from tblSales where Batch='" + DpdnBatch.SelectedItem.Text + "' and ProductName='" + DpdnProdName.SelectedItem.Text + "' and ProdBrand='" + DpdnBrand.SelectedItem.Text + "'", cons);
            cons.Open();
            int cnt = (Int32)cmdcount.ExecuteScalar();
            cons.Close();
            if(cnt>0)
            {
                cmd = new SqlCommand("select sum(Qnty)[Sales] from tblSales where Batch='" + DpdnBatch.SelectedItem.Text + "' and ProductName='" + DpdnProdName.SelectedItem.Text + "' and ProdBrand='" + DpdnBrand.SelectedItem.Text + "'", cons);
                cons.Open();
                SqlDataReader rd2 = cmd.ExecuteReader();
                if (rd2.HasRows)
                {
                    while (rd2.Read())
                    {
                        SalesQnty = Convert.ToInt32(rd2["Sales"].ToString());
                    }
                }
                cons.Close();
                rd2.Close();
                cmd.Dispose();
            }
            remainingqty = purchaseQnty - SalesQnty;
            lblAvailability.Text = remainingqty.ToString();
            string prodname = DpdnProdName.SelectedItem.Text;
            string brand = DpdnBrand.SelectedItem.Text;
            var rate = (from c in db.tblPurchaseBills where c.ProductName==prodname select c.RatePerUnit).FirstOrDefault();
            txtRate.Text = rate.ToString();
            lblPurchaseRate.Text = rate.ToString();
            cmd = new SqlCommand("select Mrp4unit from tblPurchaseBill where BatchNo='"+DpdnBatch.SelectedItem.Text+"' and ProductName='"+DpdnProdName.SelectedItem.Text+"' and Brand='"+DpdnBrand.SelectedItem.Text+"' and ProdFlavor='"+DpdnFlavor.SelectedItem.Text+"'",cons);
            //SqlDataReader rd3;
            cons.Open();
            decimal mrp4unit = (decimal)cmd.ExecuteScalar();
            cons.Close();
            txtMrp4unit.Text = mrp4unit.ToString();
        }

        protected void DpdnSaleby_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DpdnSaleby.SelectedIndex!=0)
            {
                decimal qnty=0.00M, rate = 0.00M, mrp = 0.00M, totval = 0.00M;
                qnty = Convert.ToDecimal(txtQnty.Text);
                rate = Convert.ToDecimal(txtRate.Text);
                mrp = Convert.ToDecimal(txtMrp4unit.Text);
                if (DpdnSaleby.SelectedIndex==1)
                {
                    totval = rate * qnty;
                    gstvalue = rate * qnty;
                }
                else
                {
                    totval = mrp * qnty;
                    gstvalue = mrp * qnty;
                }
                txtAmt.Text = totval.ToString();
                profitcalc();
            }
        }

        protected void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            discountCalc();
            profitcalc();
        }

        protected void discountCalc()
        {
            decimal amt = 0.00M, disct = 0.00M;
            disct = Convert.ToDecimal(txtDiscount.Text);
            amt = Convert.ToDecimal(txtAmt.Text);
            if (DpdnDiscntType.SelectedIndex != 0)
            {
                if (DpdnDiscntType.SelectedIndex == 1)
                {
                    lblDiscount.Text = disct.ToString();
                    amt = amt - disct;
                }
                else
                {
                    disct = (amt * (disct / 100));
                    lblDiscount.Text = disct.ToString();
                    amt = amt - disct;
                }
                txtAmt.Text = amt.ToString();
            }
        }

        protected void profitcalc()
        {
            decimal rate, qnty, proft, calcamt, amount = 0;
            calcamt = Convert.ToDecimal(txtAmt.Text);
            rate = Convert.ToDecimal(lblPurchaseRate.Text);
            qnty = Convert.ToDecimal(txtQnty.Text);
            amount = rate * qnty;
            lblActualPrice.Text = amount.ToString();
            proft = calcamt - amount;
            lblProfit.Text = proft.ToString();
        }

        protected void DpdnDiscntType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtQnty_TextChanged(object sender, EventArgs e)
        {
            decimal actualrate, qty = 0, tot = 0;
            qty = Convert.ToDecimal(txtQnty.Text);
            actualrate = Convert.ToDecimal(lblPurchaseRate.Text);
            if(txtQnty.Text!="" || txtQnty.Text!="0")
            {
                tot = actualrate * qty;
            }
            lblActualPrice.Text = tot.ToString();
        }
    }
}