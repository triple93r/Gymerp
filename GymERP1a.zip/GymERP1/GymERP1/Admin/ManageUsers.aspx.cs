﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace GymERP1.Admin
{
    public partial class ManageUsers : System.Web.UI.Page
    {
        SqlConnection cons = new SqlConnection(ConfigurationManager.ConnectionStrings["d1"].ConnectionString);
        GymERP1Entities1 db = new GymERP1Entities1();
        //SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            using (var cont = new GymERP1Entities1())
            {
                var tblusr = new tblUser()
                {
                    User_Name = txtUserName.Text,
                    UPasswrd = txtPasswrd.Text,
                    usertype = DpdnUserType.SelectedItem.Text 
                };
                cont.tblUsers.Add(tblusr);
                cont.SaveChanges();
                lblConfirm.Text = "User Added Successfully!";
            }
        }
    }
}